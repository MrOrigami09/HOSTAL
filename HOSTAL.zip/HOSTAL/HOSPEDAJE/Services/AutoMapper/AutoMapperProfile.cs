﻿using AutoMapper;
using HOSPEDAJE.Areas.ListaEsperaArea.DTOs;

using HOSPEDAJE.Models;

namespace HOSPEDAJE.Services.AutoMapper
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {

            CreateMap<TblListaEspera, ListaEsperaDTO>().ReverseMap();
        }
    }
}
