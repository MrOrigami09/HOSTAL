﻿using HOSPEDAJE.Areas.ListaEsperaArea.Repositories.Implementacion;
using HOSPEDAJE.Areas.ListaEsperaArea.Repositories.Interface;
using HOSPEDAJE.Areas.ListaEsperaArea.Services.Implementacion;
using HOSPEDAJE.Areas.ListaEsperaArea.Services.Interface;
using HOSPEDAJE.Areas.ListaEsperaArea.Services.Microservicios.RegistrarListaEspera;
using HOSPEDAJE.PatronUnitOfWork.Implementacion;
using HOSPEDAJE.PatronUnitOfWork.Interface;
using HOSPEDAJE.Services.AutoMapper;

namespace HOSPEDAJE.Services
{
    public static class RegistroDeServicios
    {
        public static void AddAplicationServices(this IServiceCollection services)
        {
            // Configuración de Controladores y Vistas
            services.AddControllersWithViews(options =>
            {
                options.ModelValidatorProviders.Clear();
            });

            // Registro de AutoMapper
            services.AddAutoMapper(typeof(AutoMapperProfile));

            // Inyección de Repositorios
            services.AddScoped<IListaEsperaRepository, ListaEsperaRepository>();

            // Inyección de Servicios
            services.AddScoped<IListaEsperaService, ListaEsperaService>();

            // Inyección de Microservicios
            services.AddScoped<IRegistrarListaEsperaMicroService, RegistrarListaEsperaMicroService>();

            // Inyección de UnitOfWork
            services.AddScoped<IUnitOfWork, UnitOfWork>();
        }
    }
}

