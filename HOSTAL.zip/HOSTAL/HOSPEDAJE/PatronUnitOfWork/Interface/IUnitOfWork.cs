﻿namespace HOSPEDAJE.PatronUnitOfWork.Interface
{
    /**************************** INTERFAZ PARA UNIDAD DE TRABAJO ********************************/

    public interface IUnitOfWork : IDisposable
    {

        /**************************** INICIAR TRANSACCIÓN ASÍNCRONA **********************************/

        Task BeginTransactionAsync();

        /**************************** GUARDAR CAMBIOS ASÍNCRONOS *************************************/

        Task<int> SaveChangesAsync();

        /**************************** CONFIRMAR TRANSACCIÓN ASÍNCRONA ********************************/

        Task CommitTransactionAsync();

        /**************************** DESHACER TRANSACCIÓN ASÍNCRONA ********************************/

        Task RollbackTransactionAsync();
    }
}
