﻿using HOSPEDAJE.Data;
using HOSPEDAJE.PatronUnitOfWork.Interface;
using Microsoft.EntityFrameworkCore.Storage;

namespace HOSPEDAJE.PatronUnitOfWork.Implementacion
{
    public class UnitOfWork : IUnitOfWork
    {
        //
        /**************************** INYECCIÓN DE DEPENDENCIAS Y PROPIEDADES *************************/
        //
        private readonly ApplicationDbContext _DbContext;
        private IDbContextTransaction _transaccionActual;

        public UnitOfWork(ApplicationDbContext context)
        {
            _DbContext = context;
        }

        /**************************** INICIAR TRANSACCIÓN ASÍNCRONA **********************************/

        public async Task BeginTransactionAsync()
        {
            _transaccionActual = await _DbContext.Database.BeginTransactionAsync();
        }

        /**************************** GUARDAR CAMBIOS ASÍNCRONOS *************************************/

        public async Task<int> SaveChangesAsync()
        {
            return await _DbContext.SaveChangesAsync();
        }

        /**************************** CONFIRMAR TRANSACCIÓN ASÍNCRONA ********************************/

        public async Task CommitTransactionAsync()
        {
            if (_transaccionActual != null)
            {
                await _transaccionActual.CommitAsync();
                await _transaccionActual.DisposeAsync();
                _transaccionActual = null;
            }
        }
        //
        /**************************** DESHACER TRANSACCIÓN ASÍNCRONA ********************************/
        //
        public async Task RollbackTransactionAsync()
        {
            if (_transaccionActual != null)
            {
                await _transaccionActual.RollbackAsync();
                await _transaccionActual.DisposeAsync();
                _transaccionActual = null;
            }
        }

        /**************************** LIBERAR RECURSOS **********************************************/

        public void Dispose()
        {
            _DbContext.Dispose();
        }
    }


}
