﻿using HOSPEDAJE.Areas.ListaEsperaArea.Repositories.Interface;
using HOSPEDAJE.Data;
using HOSPEDAJE.Models;
using Microsoft.EntityFrameworkCore;

namespace HOSPEDAJE.Areas.ListaEsperaArea.Repositories.Implementacion
{
    public class ListaEsperaRepository : IListaEsperaRepository
    {
        public readonly ApplicationDbContext _DBContext;

        public ListaEsperaRepository(ApplicationDbContext dBContext)
        {
            _DBContext = dBContext;
        }

        public async Task RegistrarListaEspera(TblListaEspera listaesperaregistrar)
        {
            await _DBContext.TblListaEsperas.AddAsync(listaesperaregistrar);

        }

        public async Task<List<TblListaEspera>> ObtenerTodos()
        {
            return await _DBContext.TblListaEsperas.ToListAsync();
        }

        public async Task<TblListaEspera?> ObtenerPorId(int id)
        {
            return await _DBContext.TblListaEsperas.FindAsync(id);
        }

        public void Actualizar(TblListaEspera listaEspera)
        {
            var entidadExistente = _DBContext.TblListaEsperas.Find(listaEspera.IdEspera);
            if (entidadExistente != null)
            {
                entidadExistente.Prioridad = listaEspera.Prioridad;
                entidadExistente.Estado = listaEspera.Estado;
                entidadExistente.Descripcion = listaEspera.Descripcion;

                // Otras propiedades si es necesario
                _DBContext.Entry(entidadExistente).State = EntityState.Modified;
            }
        }

        public async Task Eliminar(int id)
        {
            var listaEspera = await _DBContext.TblListaEsperas.FindAsync(id);
            if (listaEspera != null)
            {
                _DBContext.TblListaEsperas.Remove(listaEspera);
            }
            _DBContext.TblListaEsperas.Remove(listaEspera);
        }


        public async Task<bool> TieneRegistroPendiente(int idCliente)
        {
            return await _DBContext.TblListaEsperas
                .AnyAsync(le => le.IdCliente == idCliente && le.Estado == "E");
        }


    }
}
