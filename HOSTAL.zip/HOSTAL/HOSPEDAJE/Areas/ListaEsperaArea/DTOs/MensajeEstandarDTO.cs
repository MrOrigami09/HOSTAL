﻿namespace HOSPEDAJE.Areas.ListaEsperaArea.DTOs
{
    public class MensajeEstandarDTO
    {
        public bool EsExito {  get; set; }
        public string Descripcion { get; set; }

        public MensajeEstandarDTO( bool esExito, string descripcion) 
        {
            EsExito = esExito;
            Descripcion = descripcion;
        }


    }
}
