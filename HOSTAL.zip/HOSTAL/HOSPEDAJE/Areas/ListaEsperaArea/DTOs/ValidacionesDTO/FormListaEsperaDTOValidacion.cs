﻿using FluentValidation;
namespace HOSPEDAJE.Areas.ListaEsperaArea.DTOs.ValidacionesDTO
{
    public class FormListaEsperaDTOValidacion : AbstractValidator<ListaEsperaDTO>   
    {
        public FormListaEsperaDTOValidacion()
        {
            RuleFor(ListaEspera => ListaEspera.IdCliente)
            .NotEmpty().WithMessage("ID CLIENTE ES OBLIGATORIO");

            RuleFor(ListaEspera => ListaEspera.Prioridad)
            .NotEmpty().WithMessage("PRIORIDAD ES OBLIGATORIO");

            RuleFor(listaEspera => listaEspera.Estado)
            .Must(estado => estado == "E" || estado == "N")
            .WithMessage("El estado debe ser ESPERA (E) o NOTIFICADO (N).");

            /* RuleFor(ListaEspera => ListaEspera.Estado)
            .NotEmpty().WithMessage("ESTADO ES OBLIGATORIO"); */

            RuleFor(ListaEspera => ListaEspera.Descripcion)
            .NotEmpty().WithMessage("DESCRIPCION ES OBLIGATORIO");

        }
    }
}
