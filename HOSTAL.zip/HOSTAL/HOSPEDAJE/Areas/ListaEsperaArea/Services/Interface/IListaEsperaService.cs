﻿using HOSPEDAJE.Areas.ListaEsperaArea.DTOs;

namespace HOSPEDAJE.Areas.ListaEsperaArea.Services.Interface
{
    public interface IListaEsperaService
    {
        Task<MensajeEstandarDTO> RegistrarListaEspera(ListaEsperaDTO ControladorListaEsperaDTO);
        Task<List<ListaEsperaDTO>> ObtenerTodos();
        Task<ListaEsperaDTO?> ObtenerPorId(int id);
        Task<MensajeEstandarDTO> Actualizar(ListaEsperaDTO listaEspera);
        Task<MensajeEstandarDTO> Eliminar(int id);
    }
}
