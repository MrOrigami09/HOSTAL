﻿using AutoMapper;
using HOSPEDAJE.Areas.ListaEsperaArea.DTOs;
using HOSPEDAJE.Areas.ListaEsperaArea.Repositories.Interface;
using HOSPEDAJE.Areas.ListaEsperaArea.Services.Interface;
using HOSPEDAJE.Areas.ListaEsperaArea.Services.Microservicios.RegistrarListaEspera;
using HOSPEDAJE.Models;
using HOSPEDAJE.PatronUnitOfWork.Implementacion;
using HOSPEDAJE.PatronUnitOfWork.Interface;

namespace HOSPEDAJE.Areas.ListaEsperaArea.Services.Implementacion
{
    public class ListaEsperaService : IListaEsperaService
    {
        public readonly IUnitOfWork _iunitOfWork;
        public readonly IRegistrarListaEsperaMicroService _iRegistrarListaEsperaMicroService;
        private readonly IListaEsperaRepository _listaEsperaRepository;
        private readonly IMapper _mapper;

        public ListaEsperaService(
            IUnitOfWork iunitOfWork,
            IRegistrarListaEsperaMicroService iRegistrarListaEsperaMicroService,
            IListaEsperaRepository listaEsperaRepository, IMapper mapper)
        {
            _iunitOfWork = iunitOfWork;
            _iRegistrarListaEsperaMicroService = iRegistrarListaEsperaMicroService;
            _listaEsperaRepository = listaEsperaRepository;
            _mapper = mapper;
        }

        public async Task<MensajeEstandarDTO> RegistrarListaEspera(ListaEsperaDTO ControladorListaEsperaDTO)
        {
            try
            {
                // Validar si el usuario tiene un registro pendiente en estado "E"
                bool tienePendiente = await _listaEsperaRepository.TieneRegistroPendiente(ControladorListaEsperaDTO.IdCliente);

                if (tienePendiente)
                {
                    return new MensajeEstandarDTO(false, "USTED TIENE UN REGISTRO DE ESPERA PENDIENTE");
                }

                // Configurar estado por defecto
                ControladorListaEsperaDTO.Estado = "E";

                await _iunitOfWork.BeginTransactionAsync();
                var mensajeregistrolistaespera = await _iRegistrarListaEsperaMicroService.RegistrarListaEspera(ControladorListaEsperaDTO);

                if (!mensajeregistrolistaespera.EsExito)
                {
                    await _iunitOfWork.RollbackTransactionAsync();
                    return new MensajeEstandarDTO(false, mensajeregistrolistaespera.Descripcion);
                }

                await _iunitOfWork.SaveChangesAsync();
                await _iunitOfWork.CommitTransactionAsync();

                return new MensajeEstandarDTO(true, "Registro exitoso.");
            }
            catch (Exception ex)
            {
                await _iunitOfWork.RollbackTransactionAsync();
                return new MensajeEstandarDTO(false, $"Error al registrar: {ex.Message}");
            }
        }


        /* public async Task<MensajeEstandarDTO> RegistrarListaEspera(ListaEsperaDTO ControladorListaEsperaDTO)
        {
            try
            {
                // Garantizar que el estado sea "E" por defecto
                ControladorListaEsperaDTO.Estado = "E";

                await _iunitOfWork.BeginTransactionAsync();
                var mensajeregistrolistaespera = await _iRegistrarListaEsperaMicroService.RegistrarListaEspera(ControladorListaEsperaDTO);

                if (!mensajeregistrolistaespera.EsExito)
                {
                    await _iunitOfWork.RollbackTransactionAsync();
                    return new MensajeEstandarDTO(false, mensajeregistrolistaespera.Descripcion);
                }

                await _iunitOfWork.SaveChangesAsync();
                await _iunitOfWork.CommitTransactionAsync();

                return new MensajeEstandarDTO(true, "Registro exitoso.");
            }
            catch (Exception ex)
            {
                await _iunitOfWork.RollbackTransactionAsync();
                return new MensajeEstandarDTO(false, $"Error al registrar: {ex.Message}");
            }
        } */


        /* public async Task<MensajeEstandarDTO> RegistrarListaEspera(ListaEsperaDTO ControladorListaEsperaDTO)
        {
            try
            {
                await _iunitOfWork.BeginTransactionAsync();
                var mensajeregistrolistaespera = await _iRegistrarListaEsperaMicroService.RegistrarListaEspera(ControladorListaEsperaDTO);
                if(!mensajeregistrolistaespera.EsExito)
                {
                    await _iunitOfWork.RollbackTransactionAsync();
                    return new MensajeEstandarDTO(false,mensajeregistrolistaespera.Descripcion);
                }
                //agregar microservicios
                await _iunitOfWork.SaveChangesAsync();
                await _iunitOfWork.CommitTransactionAsync();
                

                return mensajeregistrolistaespera;
            }
            catch (Exception ex) 
            {
                await _iunitOfWork.RollbackTransactionAsync();
                var mensajeError = $"Error al Registrar: { ex.Message}.Detalle: { ex.InnerException?.Message }";
                return new MensajeEstandarDTO(false , mensajeError);
            }

        } */

        public async Task<List<ListaEsperaDTO>> ObtenerTodos()
        {
            var entidades = await _listaEsperaRepository.ObtenerTodos();
            return _mapper.Map<List<ListaEsperaDTO>>(entidades);
        }

        public async Task<ListaEsperaDTO?> ObtenerPorId(int id)
        {
            var entidad = await _listaEsperaRepository.ObtenerPorId(id);
            return _mapper.Map<ListaEsperaDTO?>(entidad);
        }

        public async Task<MensajeEstandarDTO> Actualizar(ListaEsperaDTO listaEspera)
        {
            try
            {
                var entidad = _mapper.Map<TblListaEspera>(listaEspera);
                _listaEsperaRepository.Actualizar(entidad);
                await _iunitOfWork.SaveChangesAsync();
                return new MensajeEstandarDTO(true, "Actualización exitosa");
            }
            catch (Exception ex)
            {
                return new MensajeEstandarDTO(false, $"Error al actualizar: {ex.Message}");
            }
        }

        public async Task<MensajeEstandarDTO> Eliminar(int id)
        {
            try
            {
                await _listaEsperaRepository.Eliminar(id);
                await _iunitOfWork.SaveChangesAsync();
                return new MensajeEstandarDTO(true, "Eliminación exitosa");
            }
            catch (Exception ex)
            {
                return new MensajeEstandarDTO(false, $"Error al eliminar: {ex.Message}");
            }
        }



    }
}
