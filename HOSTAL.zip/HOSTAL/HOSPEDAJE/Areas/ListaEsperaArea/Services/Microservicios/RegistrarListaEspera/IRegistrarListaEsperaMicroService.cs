﻿using HOSPEDAJE.Areas.ListaEsperaArea.DTOs;

namespace HOSPEDAJE.Areas.ListaEsperaArea.Services.Microservicios.RegistrarListaEspera
{
    public interface IRegistrarListaEsperaMicroService
    {
        Task<MensajeEstandarDTO> RegistrarListaEspera(ListaEsperaDTO ServiceListaEsperaDTO);
    }
}
