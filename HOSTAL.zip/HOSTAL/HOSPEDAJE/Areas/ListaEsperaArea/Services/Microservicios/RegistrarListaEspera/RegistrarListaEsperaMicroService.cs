﻿using AutoMapper;
using HOSPEDAJE.Areas.ListaEsperaArea.DTOs;
using HOSPEDAJE.Areas.ListaEsperaArea.Repositories.Interface;
using HOSPEDAJE.Areas.ListaEsperaArea.Services.Interface;
using HOSPEDAJE.Models;

namespace HOSPEDAJE.Areas.ListaEsperaArea.Services.Microservicios.RegistrarListaEspera
{
    public class RegistrarListaEsperaMicroService : IRegistrarListaEsperaMicroService
    {
        public readonly IMapper _mapper;
        public readonly IListaEsperaRepository _iListaEsperaRepository;
        public RegistrarListaEsperaMicroService(IListaEsperaRepository iListaEsperaRepository, IMapper iMapper)
        {
            _mapper = iMapper;
            _iListaEsperaRepository = iListaEsperaRepository;
        }

        public async Task<MensajeEstandarDTO> RegistrarListaEspera(ListaEsperaDTO ServiceListaEsperaDTO)
        {
            var listaesperaregistrar = _mapper.Map<TblListaEspera>(ServiceListaEsperaDTO);
            await _iListaEsperaRepository.RegistrarListaEspera(listaesperaregistrar);
            return new MensajeEstandarDTO(true, "Registro Exitoso en la Lista de Espera");
        }
    }
}
